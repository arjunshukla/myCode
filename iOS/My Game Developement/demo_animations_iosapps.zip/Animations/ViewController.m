//
//  ViewController.m
//  Animations
//
//  Created by Scott Kantner on 2/26/13.
//  Copyright (c) 2013 Scott Kantner. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController


- (void)viewDidLoad
{
    [super viewDidLoad];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
