//
//  ScramblerModel.h
//  Scrambler
//
//  Created by Arjun on 27/06/13.
//  Copyright (c) 2013 Arjun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ScramblerPlayer.h"
@interface ScramblerModel : NSObject
{
    ScramblerPlayer * computerPlayer;
    int time;
    int score;
    NSString* strCurrentWord;
}

@property (readonly) int time;
@property (readonly) int score;

// Method declaration
-(NSString*) getScrambledWord;
-(BOOL) checkGuess:(NSString*) guess;
-(void) timerTick;
@end
