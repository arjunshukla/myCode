//
//  ScramblerPlayer.m
//  Scrambler
//
//  Created by Arjun on 27/06/13.
//  Copyright (c) 2013 Arjun. All rights reserved.
//

#import "ScramblerPlayer.h"

@implementation ScramblerPlayer


-(NSString*)scrambleWord:(NSString*) wordToScramble
{
    // This method scrambles a word
    
    // Allocate an array to hold the used numbers
    NSMutableSet *setUsedNumbers = [[NSMutableSet alloc]init];
    
    // Allocate a string that will be used to build the output
    NSMutableString *strOutputString = [[NSMutableString alloc]init];
    
    // Loop the number of times that there are letters in the word
    for (int i=0; i<[wordToScramble length]; i++)
    {
        // Pick a number
        int randomNum = random()%[wordToScramble length];
        
        // Is the number in the set
        while ([setUsedNumbers containsObject:[NSNumber numberWithInt:randomNum]]==YES)
        {
            // If the number is in the list, you need to pick a different number
            randomNum = random()%[wordToScramble length];
        }
        
        // The number is not in the list
        // Add it to the list of used numbers
        [setUsedNumbers addObject:[NSNumber numberWithInt:randomNum]];
        
        // Append the character at the position choses=n to the output string
        [strOutputString appendFormat:@"%c",[wordToScramble characterAtIndex:randomNum]];
    }
    return strOutputString;
}


-(void)initializeWordList
{
    // This method creates the chosen word list
    NSArray *arrMasterWordList = [NSArray arrayWithObjects:@"well",@"coin",@"address",@"novel",@"mat",@"panther",@"chip",@"jump",@"scream",@"peacock",@"spring",@"string",@"shampoo",@"value",@"trivandrum",@"general",@"seat",@"curatin",@"window",@"thermostat",@"leaf",@"tree",@"kingdom",@"salmon",@"loaf",@"factory",@"iphone",@"pebble",@"mustard",@"sofa",@"sunglasses",@"laptop",@"computer",nil];
    
    // initialize the scrambled word list
    arrScrambledWords = [[NSMutableArray alloc]initWithCapacity:[arrMasterWordList count]];
    
    // Seed the random number generator
    srandom(time(NULL));
    int randomNum;
    
    // choose 10 words and add them to the chosen words mutable array
    for (int i; i<10; i++)
    {
        // Generate random number to pick word
        randomNum = (random()%[arrMasterWordList count]);
        // Add the word to the chosenWords mutable array
        [arrScrambledWords addObject:[arrMasterWordList objectAtIndex:randomNum]];
    }
}

-(NSString*)getNextWord
{
    NSString * strReturnedString = nil;
    if([arrScrambledWords count]>0)
    {
        strReturnedString = [arrScrambledWords objectAtIndex:0];
        // remove the string form the array
        [arrScrambledWords removeObject:0];
    }
    return strReturnedString;
}


-(int)getRemainingWordCount
{
    return [arrScrambledWords count];
}

-(id)init
{
    self = [super init];
    if (self)
    {
        [self initializeWordList];
    }
    return self;
}

@end
