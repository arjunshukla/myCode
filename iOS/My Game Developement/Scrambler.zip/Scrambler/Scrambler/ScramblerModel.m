//
//  ScramblerModel.m
//  Scrambler
//
//  Created by Arjun on 27/06/13.
//  Copyright (c) 2013 Arjun. All rights reserved.
//

#import "ScramblerModel.h"

@implementation ScramblerModel
@synthesize time,score;

-(id)init
{
    self = [super init];
    if(self)
    {
        // Initialize the game model
        computerPlayer = [[ScramblerPlayer alloc]init];
        
        // initialize time
        time =60;
        
        // initialize score
        score = 0;
        
        // Get the first word from the list
        strCurrentWord = [computerPlayer getNextWord];
    }
    return self;
}

-(NSString*) getScrambledWord
{
    return [computerPlayer scrambleWord:strCurrentWord];
}

-(BOOL) checkGuess:(NSString*) guess
{
    if ([guess isEqualToString:strCurrentWord])
    {
        // Add one to the score
        score++;
        
        // Add 15 seconds to the timer
        time +=15;
        
        // If there are more words, pick the next word
        if ([computerPlayer getRemainingWordCount]>0)
        {
            strCurrentWord = [computerPlayer getNextWord];
        }
        else
        {
            // No more words, so clean up
            strCurrentWord = nil;
        }
        return YES;
    }
    else
    {
        // Substract 10 from the timer;
        time-=10;
        return NO;
    }
}

-(void) timerTick
{
    time--;
}
 
@end
