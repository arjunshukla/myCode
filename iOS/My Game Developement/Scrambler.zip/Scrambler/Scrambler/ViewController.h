//
//  ViewController.h
//  Scrambler
//
//  Created by Arjun on 27/06/13.
//  Copyright (c) 2013 Arjun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ScramblerModel.h"
@interface ViewController : UIViewController
{
    ScramblerModel *objGameModel;
    NSTimer* gameTimer;
}

@property (strong, nonatomic) IBOutlet UILabel *lblScrambledWord;
@property (strong, nonatomic) IBOutlet UILabel *lblRemainingTime;
@property (strong, nonatomic) IBOutlet UILabel *lblPlayerScore;
@property (strong, nonatomic) IBOutlet UITextField *txtGuessText;
- (IBAction)btnGuess:(id)sender;
-(void)endgameWithMessage:(NSString*)message;
@end
