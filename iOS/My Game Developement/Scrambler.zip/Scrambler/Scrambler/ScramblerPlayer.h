//
//  ScramblerPlayer.h
//  Scrambler
//
//  Created by Arjun on 27/06/13.
//  Copyright (c) 2013 Arjun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ScramblerPlayer : NSObject
{
    // Choose the scrambled words for the game
    NSMutableArray * arrScrambledWords;
}

// Game methods
-(NSString*)getNextWord;
-(NSString*)scrambleWord:(NSString*) wordToScramble;
-(int)getRemainingWordCount;
-(void)initializeWordList;
@end
