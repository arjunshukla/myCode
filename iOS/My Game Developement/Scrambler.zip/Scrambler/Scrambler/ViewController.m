//
//  ViewController.m
//  Scrambler
//
//  Created by Arjun on 27/06/13.
//  Copyright (c) 2013 Arjun. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize lblScrambledWord;
@synthesize lblRemainingTime;
@synthesize lblPlayerScore;
@synthesize txtGuessText;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    // Initialize the objgameModel
    objGameModel = [[ScramblerModel alloc]init];
    
    // Display the time, score and the scrambled word in the view
    lblRemainingTime.text = [NSString stringWithFormat:@"%i",objGameModel.time];
    lblPlayerScore.text = [NSString stringWithFormat:@"%i",objGameModel.score];
    lblScrambledWord.text = [objGameModel getScrambledWord];
    
    // start the game timer
    gameTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timerFired:) userInfo:nil repeats:YES];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload
{
    
    [self setLblScrambledWord:nil];
    [self setLblRemainingTime:nil];
    [self setLblPlayerScore:nil];
    [self setTxtGuessText:nil];
    objGameModel = nil;
    [super viewDidUnload];
}
- (IBAction)btnGuess:(id)sender
{
    // check teh guess against the current word
    BOOL guessCorrect = [objGameModel checkGuess:txtGuessText.text];
    
    // clear the guess text UITextField
    txtGuessText.text=@"";
    if(guessCorrect)
    {
        if(objGameModel.score==10)
        {
            // the game is over
            [self endgameWithMessage:@"You Win"];
        }
        else
        {
            // update the view with the next scrambled word
            lblScrambledWord.text = [objGameModel getScrambledWord];
        }
    }
    // update the view
    lblRemainingTime.text = [NSString stringWithFormat:@"%i",objGameModel.time];
    lblPlayerScore.text = [NSString stringWithFormat:@"%i",objGameModel.score];
}

-(void)endgameWithMessage:(NSString*)message
{
    // this method ends the game
    // invalidate the timer
    [gameTimer invalidate];
    
    // show an alert with the results
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"GAME OVER" message:message delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

-(void)timerFired:(NSTimer*)theTimer
{
    // the timer fires this method every second
    [objGameModel timerTick];
    
    if (objGameModel.time<=0)
    {
        lblRemainingTime.text = 0;
        [self endgameWithMessage:@"TIME's UP !!/n YOU LOOSE :P"];
    }
    else
    {
        lblRemainingTime.text = [NSString stringWithFormat:@"%@",objGameModel.time];
    }
}
@end
